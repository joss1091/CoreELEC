# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2009-2013 Stephan Raue (stephan@openelec.tv)
# Copyright (C) 2013 Lutz Fiebach (lufie@openelec.tv)
# Copyright (C) 2018-present Team CoreELEC (https://coreelec.org)

import oe
import xbmc
import time
import threading

class service_thread(threading.Thread):

    def __init__(self, oeMain):
        try:
            self.oe = oeMain
            self.wait_evt = threading.Event()
            self.stopped = False
            threading.Thread.__init__(self)
            self.daemon = True

        except Exception, e:
            raise

    def stop(self):
        try:
            self.stopped = True
        except Exception, e:
            raise

    def run(self):
        try:
            while True:
                active = self.oe.verify_subscription()
                if active == True and self.oe.winOeMain.visible == True:
                    self.oe.winOeMain.close()
                    self.oe.winOeMain.visible = False
                elif active == False and self.oe.winOeMain.visible == False:
                    threading.Thread(target=self.oe.openWindow).start()
                    self.oe.winOeMain.visible = True
                    self.oe.stop_player()

                time.sleep(600)
        except Exception, e:
            raise


class cxbmcm(xbmc.Monitor):

    def __init__(self, *args, **kwargs):
        xbmc.Monitor.__init__(self)

    def onScreensaverActivated(self):
        pass

    def onAbortRequested(self):
        pass


xbmcm = cxbmcm()
monitor = service_thread(oe.__oe__)
monitor.start()

xbmcm.waitForAbort()
monitor.stop()
